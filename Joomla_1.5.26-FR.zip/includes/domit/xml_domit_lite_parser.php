<?php
/**
 * Legacy Mode compatibility
 * @version		$Id: xml_domit_lite_parser.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla.Legacy
 */
require_once( dirname(__FILE__)  .'/../../libraries/domit/xml_domit_lite_parser.php' );