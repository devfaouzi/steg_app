<?php
/**
 * Legacy Mode compatibility
 * @version		$Id: vcard.class.php 10381 2008-06-01 03:35:53Z pasamio $
 * @package		Joomla.Legacy
 */
require_once( dirname(__FILE__)  .'/../libraries/bitfolge/vcard.php' );